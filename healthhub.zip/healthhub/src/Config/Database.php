<?php
namespace Healthhub\Emr\Config;

use PDO;
use PDOException;

final class Database {
    private static ?PDO $pdo = null;

    public static function pdo(): PDO {
        if (!self::$pdo) {
            $dsn = "mysql:host=localhost;dbname=healthhub;charset=utf8mb4";
            $user = "root";
            $pass = "";
            try {
                self::$pdo = new PDO($dsn, $user, $pass, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);
            } catch (PDOException $e) {
                die("Erro ao conectar no banco: " . $e->getMessage());
            }
        }
        return self::$pdo;
    }
}
