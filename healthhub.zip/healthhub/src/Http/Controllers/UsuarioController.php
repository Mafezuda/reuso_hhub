<?php
namespace Healthhub\Emr\Http\Controllers;

use Healthhub\Emr\Core\Controller;
use Healthhub\Emr\Domain\Entities\Usuario;

class UsuarioController extends Controller {

    private function requireAuth(): void {
        session_start();
        if (empty($_SESSION['user_id'])) {
            $this->redirect('/healthhub/public/index.php');
        }
    }

    public function home(): void {
        $this->requireAuth();
        $users = Usuario::all();
        $this->view('usuario/index', compact('users'));
    }

    public function createForm(): void {
        $this->requireAuth();
        $this->view('usuario/create');
    }

    public function store(): void {
        $this->requireAuth();

        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($name === '' || $email === '' || $password === '') {
            $error = "Preencha todos os campos.";
            $this->view('usuario/create', compact('error', 'name', 'email'));
            return;
        }

        if (Usuario::findByEmail($email)) {
            $error = "E-mail já cadastrado.";
            $this->view('usuario/create', compact('error', 'name', 'email'));
            return;
        }

        $u = new Usuario();
        $u->name = $name;
        $u->email = $email;
        $u->password_hash = password_hash($password, PASSWORD_BCRYPT);
        $u->save();

        $this->redirect('/healthhub/public/usuario/index.php');
    }

    public function edit(): void {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);
        $usuario = Usuario::find($id);
        if (!$usuario) {
            $this->redirect('/healthhub/public/usuario/index.php');
        }
        $this->view('usuario/edit', compact('usuario'));
    }

    public function update(): void {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $usuario = Usuario::find($id);
        if (!$usuario) {
            $this->redirect('/healthhub/public/usuario/index.php');
        }

        $usuario->name = trim($_POST['name'] ?? '');
        $usuario->email = trim($_POST['email'] ?? '');
        if (!empty($_POST['password'])) {
            $usuario->password_hash = password_hash($_POST['password'], PASSWORD_BCRYPT);
        }
        $usuario->save();

        $this->redirect('/healthhub/public/usuario/index.php');
    }

    public function destroy(): void {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        if ($id) Usuario::delete($id);
        $this->redirect('/healthhub/public/usuario/index.php');
    }
}
