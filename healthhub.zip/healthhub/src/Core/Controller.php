<?php
namespace Healthhub\Emr\Core;

abstract class Controller {
    protected function view(string $view, array $data = []): void {
        extract($data);
        // Apenas carrega a view exata (sem header/footer automático)
        require __DIR__ . "/../../views/{$view}.php";
    }

    protected function redirect(string $path): void {
        header("Location: {$path}");
        exit;
    }
}
