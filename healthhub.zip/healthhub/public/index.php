<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Healthhub\Emr\Http\Controllers\AuthController;

$action = $_GET['action'] ?? 'loginForm';
$controller = new AuthController();

switch ($action) {
    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') $controller->login();
        else $controller->loginForm();
        break;
    case 'logout':
        $controller->logout();
        break;
    default:
        $controller->loginForm();
        break;
}
