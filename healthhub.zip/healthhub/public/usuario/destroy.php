<?php
require_once __DIR__ . '/../../vendor/autoload.php';
use Healthhub\Emr\Http\Controllers\UsuarioController;
$ctrl = new UsuarioController();
$ctrl->destroy();
