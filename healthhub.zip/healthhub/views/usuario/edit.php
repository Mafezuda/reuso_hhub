<div class="container my-4">
  <h4>Editar Usuário #<?= $usuario->id ?></h4>
  <form method="post" action="/healthhub/public/usuario/update.php">
    <input type="hidden" name="id" value="<?= $usuario->id ?>">
    <div class="mb-3"><label>Nome</label><input type="text" name="name" value="<?= htmlspecialchars($usuario->name) ?>" class="form-control" required></div>
    <div class="mb-3"><label>Email</label><input type="email" name="email" value="<?= htmlspecialchars($usuario->email) ?>" class="form-control" required></div>
    <div class="mb-3"><label>Nova Senha (opcional)</label><input type="password" name="password" class="form-control"></div>
    <button class="btn btn-primary">Atualizar</button>
    <a href="/healthhub/public/usuario/index.php" class="btn btn-secondary">Voltar</a>
  </form>
</div>
