<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Editar Usuário | HealthHub EMR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-dark bg-primary mb-4">
  <div class="container">
    <a class="navbar-brand" href="#">HealthHub EMR</a>
    <div class="d-flex">
      <span class="navbar-text text-white me-3">
        Olá, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Usuário') ?>
      </span>
      <a href="/healthhub/public/index.php?action=logout" class="btn btn-outline-light btn-sm">Sair</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="card shadow-sm">
    <div class="card-header bg-white">
      <h5 class="m-0">Editar Usuário #<?= (int)$usuario->id ?></h5>
    </div>
    <div class="card-body">
      <form method="post" action="/healthhub/public/usuario/update.php">
        <input type="hidden" name="id" value="<?= (int)$usuario->id ?>">
        <div class="mb-3">
          <label class="form-label">Nome</label>
          <input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($usuario->name) ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">E-mail</label>
          <input type="email" name="email" class="form-control" required value="<?= htmlspecialchars($usuario->email) ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Nova Senha (opcional)</label>
          <input type="password" name="password" class="form-control">
        </div>
        <div class="d-flex justify-content-between">
          <a href="/healthhub/public/usuario/index.php" class="btn btn-secondary">Voltar</a>
          <button type="submit" class="btn btn-primary">Atualizar</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
