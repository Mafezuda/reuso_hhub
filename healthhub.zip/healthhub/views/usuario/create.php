<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Cadastrar Usuário | HealthHub EMR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-dark bg-primary mb-4">
  <div class="container">
    <a class="navbar-brand" href="#">HealthHub EMR</a>
    <div class="d-flex">
      <span class="navbar-text text-white me-3">
        Olá, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Usuário') ?>
      </span>
      <a href="/healthhub/public/index.php?action=logout" class="btn btn-outline-light btn-sm">Sair</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="card shadow-sm">
    <div class="card-header bg-white">
      <h5 class="m-0">Cadastrar Usuário</h5>
    </div>
    <div class="card-body">
      <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="post" action="/healthhub/public/usuario/create.php">
        <div class="mb-3">
          <label class="form-label">Nome</label>
          <input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($name ?? '') ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">E-mail</label>
          <input type="email" name="email" class="form-control" required value="<?= htmlspecialchars($email ?? '') ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Senha</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <div class="d-flex justify-content-between">
          <a href="/healthhub/public/usuario/index.php" class="btn btn-secondary">Voltar</a>
          <button type="submit" class="btn btn-success">Salvar</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
