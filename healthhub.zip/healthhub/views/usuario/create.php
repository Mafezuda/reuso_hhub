<div class="container my-4">
  <h4>Cadastrar Usuário</h4>
  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form method="post" action="/healthhub/public/usuario/create.php">
    <div class="mb-3"><label>Nome</label><input type="text" name="name" class="form-control" required></div>
    <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
    <div class="mb-3"><label>Senha</label><input type="password" name="password" class="form-control" required></div>
    <button class="btn btn-success">Salvar</button>
    <a href="/healthhub/public/usuario/index.php" class="btn btn-secondary">Voltar</a>
  </form>
</div>
