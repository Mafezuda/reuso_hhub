<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>HealthHub EMR - Usuários</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar única -->
<nav class="navbar navbar-dark bg-primary mb-4">
  <div class="container">
    <a class="navbar-brand" href="#">HealthHub EMR</a>
    <div class="d-flex">
      <span class="navbar-text text-white me-3">
        Olá, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Usuário') ?>
      </span>
      <a href="/healthhub/public/index.php?action=logout" class="btn btn-outline-light btn-sm">Sair</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="card shadow-sm mb-4">
    <div class="card-body d-flex justify-content-between align-items-center">
      <div>
        <h5 class="m-0">Usuários</h5>
        <small class="text-muted">Gerenciados via Database First</small>
      </div>
      <a href="/healthhub/public/usuario/create.php" class="btn btn-primary">Cadastrar Usuário</a>
    </div>
  </div>

  <div class="card shadow-sm">
    <div class="card-body p-0">
      <table class="table table-hover m-0">
        <thead class="table-light">
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Criado em</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
        <?php if (!empty($users)): ?>
          <?php foreach ($users as $u): ?>
            <tr>
              <td><?= htmlspecialchars($u->id) ?></td>
              <td><?= htmlspecialchars($u->name) ?></td>
              <td><?= htmlspecialchars($u->email) ?></td>
              <td><?= htmlspecialchars($u->created_at ?? '') ?></td>
              <td>
                <a href="/healthhub/public/usuario/edit.php?id=<?= $u->id ?>" class="btn btn-sm btn-warning">Editar</a>
                <form method="post" action="/healthhub/public/usuario/destroy.php" style="display:inline">
                  <input type="hidden" name="id" value="<?= $u->id ?>">
                  <button type="submit" class="btn btn-sm btn-danger">Excluir</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="5" class="text-center p-3">Nenhum usuário cadastrado.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
