<h3>Editar Usuário #<?= (int)$usuario->id ?></h3>
<form method="post" action="/healthhub/public/usuario/update.php">
  <input type="hidden" name="id" value="<?= (int)$usuario->id ?>">
  <label>Nome
    <input type="text" name="name" value="<?= htmlspecialchars($usuario->name) ?>" required>
  </label>
  <label>E-mail
    <input type="email" name="email" value="<?= htmlspecialchars($usuario->email) ?>" required>
  </label>
  <label>Senha (deixe em branco para manter)
    <input type="password" name="password">
  </label>
  <button type="submit">Atualizar</button>
</form>
